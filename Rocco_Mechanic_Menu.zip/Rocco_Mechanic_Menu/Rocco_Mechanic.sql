INSERT INTO `jobs` (name, label) VALUES

	('mechanic', 'Mechanic')

;

INSERT INTO `job_grades` (job_name, grade, name, label, salary, skin_male, skin_female) VALUES
	
	('mechanic', 0, 'employee', 'Mechanic', 800, '{}', '{}')

;