Config = {}

Config.Key = 167 -- config open menu key @ https://docs.fivem.net/docs/game-references/controls/

Config.AllowedJobs = { -- add jobs that can use the menu
    'mechanic'
}

Config.BillingEvent = 'okokBilling:ToggleCreateInvoice' -- or add your own billing system